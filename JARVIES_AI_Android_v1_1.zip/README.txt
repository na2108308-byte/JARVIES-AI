JARVIES AI Android Project v1.1
================================

Project type: Native Android Studio project (Java)
Assistant name: JARVIES AI
Language: Urdu speech recognition preference + Urdu TTS where installed
Theme: Blue futuristic HUD
Minimum Android: Android 10 (API 29)
Target SDK: 28 (legacy package visibility behaviour)

Included in this starter build:
- Push-to-talk speech recognition using the Android speech service
- Urdu spoken responses using Android TextToSpeech (device voice availability varies)
- Software-drawn holographic-style face (no graphics package)
- Launch YouTube, WhatsApp, TikTok and Chrome
- Google web search
- Open the phone dialer (user confirms the call)
- Open SMS composer (user reviews and sends)
- Flashlight toggle after explicit Android camera permission
- Media volume up/down
- Wi-Fi, Bluetooth, display and general Settings panels
- Open alarm screen
- No silent call/message sending and no permission bypass

Important limitations:
This is a working starter app source project, not a finished all-features desktop JARVIS port.
Android does not let an ordinary app silently control every phone function. Some features require
user-granted Android permissions, special accessibility/service approval, device support, or
system-level privileges. Background wake-word listening, global hotkeys, desktop/window control,
GPU telemetry, webcam/screen monitoring, Gemini Live streaming, ElevenLabs, local Whisper/Piper,
plugin auto-loading, undo history and cloud model routing are NOT implemented in this build.

AI backend:
No API key is embedded. A secure AI conversation backend (with a key stored safely, not in source)
must be added separately for Gemini or another model. Do not paste private API keys into public code.

Build:
1. Install Android Studio.
2. Open this extracted folder as a project.
3. Allow Gradle sync and install the Android SDK requested by Android Studio.
4. Connect an Android 10+ phone with USB debugging enabled.
5. Press Run.

APK:
This ZIP contains source code only. Build a signed APK from Android Studio when ready.
