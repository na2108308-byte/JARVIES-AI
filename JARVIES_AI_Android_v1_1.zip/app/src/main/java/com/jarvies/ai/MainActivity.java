package com.jarvies.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int SPEECH_REQUEST = 101;
    private static final int CAMERA_REQUEST = 102;
    private TextView status, heard;
    private TextToSpeech tts;
    private CameraManager cameraManager;
    private String flashCameraId;
    private boolean torchOn = false;
    private final AudioManager audio = (AudioManager) null;
    private final String cyan = "#00D5FF";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5,11,24));
        getWindow().setNavigationBarColor(Color.rgb(5,11,24));
        cameraManager = (CameraManager)getSystemService(CAMERA_SERVICE);
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int language = tts.setLanguage(new Locale("ur", "PK"));
                tts.setSpeechRate(0.90f);
                if (language == TextToSpeech.LANG_MISSING_DATA ||
                    language == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(new Locale("en", "US"));
                }
            }
        });
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(22,20,22,20);
        root.setBackgroundColor(Color.rgb(5,11,24));

        TextView title = new TextView(this);
        title.setText("亗 JARVIES AI 亗");
        title.setTextColor(Color.parseColor(cyan));
        title.setTextSize(28); title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("URDU VOICE ASSISTANT  •  ANDROID 10+");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setTextSize(11);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0,4,0,10);
        root.addView(subtitle);

        root.addView(new HoloFace(this), new LinearLayout.LayoutParams(
            dp(210), dp(210)));

        status = new TextView(this);
        status.setText("JARVIES online hai. Mic dabayein.");
        status.setTextColor(Color.WHITE); status.setTextSize(17);
        status.setGravity(Gravity.CENTER); status.setPadding(8,12,8,12);
        root.addView(status);

        Button mic = button("🎙  PUSH TO TALK");
        root.addView(mic);
        mic.setOnClickListener(v -> startListening());

        heard = new TextView(this);
        heard.setText("Aapki command yahan nazar aayegi.");
        heard.setTextColor(Color.parseColor("#B9D7E5"));
        heard.setTextSize(14); heard.setGravity(Gravity.CENTER);
        heard.setPadding(8,10,8,12);
        root.addView(heard);

        Button commands = button("COMMANDS / MADAD");
        root.addView(commands);
        commands.setOnClickListener(v -> speak(
            "Aap keh sakte hain: YouTube kholo, WhatsApp kholo, flashlight on karo, volume kam karo, WiFi settings kholo, alarm lagao, Google par search karo, ya call screen kholo."
        ));

        TextView safety = new TextView(this);
        safety.setText("Privacy: mic sirf Push-to-Talk dabane par speech service kholta hai. Calls aur messages aap khud review aur confirm karte hain. Android ki security permissions ko bypass nahi kiya jata.");
        safety.setTextColor(Color.GRAY); safety.setTextSize(11);
        safety.setGravity(Gravity.CENTER); safety.setPadding(8,14,8,0);
        root.addView(safety);
        setContentView(root);
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(14);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0,105,150)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,6,0,6); b.setLayoutParams(p);
        return b;
    }

    private void startListening() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIES ko command dein");
        try { startActivityForResult(i, SPEECH_REQUEST); }
        catch (Exception e) { speak("Speech recognition service available nahi hai."); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if (request == SPEECH_REQUEST && result == RESULT_OK && data != null) {
            ArrayList<String> list = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (list != null && !list.isEmpty()) {
                String command = list.get(0);
                heard.setText("Aap: " + command);
                handleCommand(command.toLowerCase(Locale.ROOT));
            }
        }
    }

    private void handleCommand(String c) {
        if (containsAny(c, "youtube")) openApp("com.google.android.youtube", "YouTube");
        else if (containsAny(c, "whatsapp")) openApp("com.whatsapp", "WhatsApp");
        else if (containsAny(c, "tiktok")) openApp("com.zhiliaoapp.musically", "TikTok");
        else if (containsAny(c, "chrome", "browser", "براوزر")) openApp("com.android.chrome", "Chrome");
        else if (containsAny(c, "flashlight on", "torch on", "فلیش لائٹ آن", "ٹارچ آن")) setTorch(true);
        else if (containsAny(c, "flashlight off", "torch off", "فلیش لائٹ بند", "ٹارچ بند")) setTorch(false);
        else if (containsAny(c, "volume up", "awaz barhao", "آواز بڑھاؤ")) changeVolume(true);
        else if (containsAny(c, "volume down", "awaz kam", "آواز کم کرو")) changeVolume(false);
        else if (containsAny(c, "wifi settings", "wi-fi settings", "wifi kholo", "وائی فائی")) openSettings("android.settings.panel.action.WIFI");
        else if (containsAny(c, "bluetooth settings", "bluetooth kholo", "بلوٹوتھ")) openSettings("android.settings.panel.action.BLUETOOTH");
        else if (containsAny(c, "brightness", "screen brightness", "روشنائی")) openSettings("android.settings.DISPLAY_SETTINGS");
        else if (containsAny(c, "alarm", "alarm lagao", "الارم")) setAlarm();
        else if (containsAny(c, "google", "search", "talash", "تلاش")) searchWeb(c);
        else if (containsAny(c, "call", "phone karo", "number milao", "کال")) openDialer(c);
        else if (containsAny(c, "message", "sms", "paigham", "پیغام")) openSms();
        else if (containsAny(c, "settings", "setting kholo", "سیٹنگ")) openSettings("android.settings.SETTINGS");
        else if (containsAny(c, "hello", "salam", "assalam", "السلام")) speak("Wa alaikum assalam. Main JARVIES AI hoon. Aapki kya madad karoon?");
        else speak("Maazrat, command samajh nahi aayi. Madad button dabakar commands sun sakte hain.");
    }

    private boolean containsAny(String value, String... words) {
        for (String word : words) if (value.contains(word)) return true;
        return false;
    }

    private void openApp(String pkg, String name) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch); speak(name + " khol raha hoon.");
        } else speak(name + " phone mein install nahi hai.");
    }

    private void setTorch(boolean enabled) {
        try {
            if (cameraManager == null) throw new Exception();
            if (flashCameraId == null) {
                for (String id : cameraManager.getCameraIdList()) {
                    android.hardware.camera2.CameraCharacteristics cc =
                        cameraManager.getCameraCharacteristics(id);
                    Boolean hasFlash = cc.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    Integer facing = cc.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING);
                    if (Boolean.TRUE.equals(hasFlash) &&
                        (facing == null || facing == android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK)) {
                        flashCameraId = id; break;
                    }
                }
            }
            if (flashCameraId == null) { speak("Is phone mein flashlight available nahi."); return; }
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
                speak("Flashlight ke liye camera permission dein, phir command dobara bolen.");
                return;
            }
            cameraManager.setTorchMode(flashCameraId, enabled);
            torchOn = enabled;
            speak(enabled ? "Flashlight on kar di." : "Flashlight off kar di.");
        } catch (Exception e) { speak("Flashlight control nahi ho saka."); }
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request == CAMERA_REQUEST && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
            speak("Permission mil gayi. Ab flashlight command dobara bolen.");
    }

    private void changeVolume(boolean up) {
        AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
        int direction = up ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER;
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI);
        speak(up ? "Media volume barha diya." : "Media volume kam kar diya.");
    }

    private void openSettings(String action) {
        try { startActivity(new Intent(action)); speak("Settings panel khol diya hai."); }
        catch (Exception e) { speak("Yeh settings screen is Android version par available nahi."); }
    }

    private void searchWeb(String command) {
        String q = command.replace("google","").replace("search","")
            .replace("talash karo","").replace("تلاش","").trim();
        if (q.isEmpty()) q = "latest information";
        startActivity(new Intent(Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))));
        speak("Google search khol raha hoon.");
    }

    private void openDialer(String command) {
        String digits = command.replaceAll("[^0-9+]","");
        Uri number = digits.length() >= 7 ? Uri.parse("tel:" + digits) : Uri.parse("tel:");
        try {
            startActivity(new Intent(Intent.ACTION_DIAL, number));
            speak("Phone dialer khol diya. Number check karke call aap khud karein.");
        } catch (Exception e) { speak("Phone dialer open nahi ho saka."); }
    }

    private void openSms() {
        try {
            Intent i = new Intent(Intent.ACTION_SENDTO);
            i.setData(Uri.parse("smsto:"));
            startActivity(i);
            speak("Messages app khol di. Paigham review karke khud send karein.");
        } catch (Exception e) { speak("Messages app available nahi."); }
    }

    private void setAlarm() {
        try {
            Intent i = new Intent(AlarmClock.ACTION_SHOW_ALARMS);
            startActivity(i); speak("Alarm app khol di hai. Time set kar lein.");
        } catch (Exception e) { speak("Alarm app open nahi ho saki."); }
    }

    private void speak(String text) {
        if (status != null) status.setText(text);
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvies");
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    // Lightweight software-drawn holographic face; no GPU library or extra dependency.
    private class HoloFace extends View {
        private final Paint p = new Paint(3);
        private final RectF face = new RectF();
        HoloFace(Activity a) { super(a); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight(), cx=w/2f, cy=h/2f;
            p.setColor(Color.argb(35,0,210,255)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f);
            c.drawCircle(cx,cy,Math.min(w,h)*.46f,p);
            c.drawCircle(cx,cy,Math.min(w,h)*.40f,p);
            p.setColor(Color.argb(28,0,210,255)); p.setStyle(Paint.Style.FILL);
            c.drawCircle(cx,cy,Math.min(w,h)*.36f,p);
            p.setColor(Color.rgb(0,210,255)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.4f);
            face.set(cx-w*.23f,cy-h*.34f,cx+w*.23f,cy+h*.34f);
            c.drawOval(face,p);
            // Brow, eyes, nose and mouth are intentionally stylised HUD geometry.
            p.setStrokeWidth(3f);
            c.drawLine(cx-w*.17f,cy-h*.12f,cx-w*.04f,cy-h*.14f,p);
            c.drawLine(cx+w*.04f,cy-h*.14f,cx+w*.17f,cy-h*.12f,p);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(cx-w*.105f,cy-h*.055f,4,p);
            c.drawCircle(cx+w*.105f,cy-h*.055f,4,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
            Path nose=new Path(); nose.moveTo(cx,cy-h*.03f); nose.lineTo(cx-w*.025f,cy+h*.09f); nose.lineTo(cx+w*.025f,cy+h*.09f); c.drawPath(nose,p);
            c.drawArc(cx-w*.09f,cy+h*.12f,cx+w*.09f,cy+h*.27f,15,150,false,p);
            p.setColor(Color.argb(100,0,210,255)); p.setStrokeWidth(1);
            for(int i=0;i<5;i++) c.drawLine(cx-w*.34f,cy-h*.38f+i*5,cx+w*.34f,cy-h*.38f+i*5,p);
            p.setStyle(Paint.Style.FILL); p.setTextSize(10); p.setTextAlign(Paint.Align.CENTER);
            c.drawText("SA  •  JARVIS CORE",cx, h-4,p);
        }
    }
}
